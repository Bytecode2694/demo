import { USER_LOGIN, USER_PROFILE, MOVIE_LIST } from './actionTypes';
import { fetchUsers } from "../src/APIRequest/requestMethods"

export const userLogin = (loginfo) => ({
    type: USER_LOGIN,
    username: loginfo.username === undefined ? "" : loginfo.username,
    password: loginfo.password === undefined ? "" : loginfo.password,
    isReady: loginfo.isReady,
    devicetype: '',
    domain: '',
    token: '',
    session: '',
});


export const userProfile = (info) => ({
    type: USER_PROFILE,
    firstname: info.firstname,
    lastname: '',
    department: '',
    city: '',
    salary: '',
    session: '',
});

export const movieList = (response, count) => ({
    // var response = await fetchUsers(listapi.endpoint)
    type: MOVIE_LIST,
    //"response": await fetchUsers(),
    //listapi
    response: response,
    count: count
})



