factory({
  render() {}
});

factory({
  render: function () {}
});

factory({
  'render': function () {}
});
