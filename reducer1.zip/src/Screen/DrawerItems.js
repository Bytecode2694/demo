import React from 'react';
import { Button, Text, View, StyleSheet, TouchableOpacity } from 'react-native';
export default class DrawerItems extends React.Component {
    render() {
        // style={{ backgroundColor: '#efefef', borderColor: '#fff', borderRightWidth: 10, borderTopRightRadius: 10, borderBottomRightRadius: 10, }}
        return (
            <View style={{ flex: 1, paddingTop: 100, backgroundColor: '#008b8b', borderTopRightRadius: 50, borderBottomRightRadius: 50 }}>
                <View >
                    <View style={{ height: 150, backgroundColor: '#4D3EBF', flexDirection: 'row', justifyContent: 'center', alignItems: 'center' }}>
                        <Text style={{ textAlign: 'center', color: '#fff' }}>Profile</Text>
                    </View>

                    <View style={{ height: 50, backgroundColor: '#fff', flexDirection: 'row', justifyContent: 'center', alignItems: 'center' }}>
                        <TouchableOpacity onPress={() => this.props.navigation.navigate('InfiniteList')}>
                            <Text style={{ textAlign: 'center', color: '#000' }}>Home</Text>
                        </TouchableOpacity>

                    </View>
                    <View style={{ height: 50, backgroundColor: '#fff', flexDirection: 'row', justifyContent: 'center', alignItems: 'center' }}>
                        <TouchableOpacity onPress={() => this.props.navigation.navigate('Movie')}>
                            <Text style={{ textAlign: 'center', color: '#000' }}>Movie</Text>
                        </TouchableOpacity>
                    </View>

                    <View style={{ height: 50, backgroundColor: '#fff', flexDirection: 'row', justifyContent: 'center', alignItems: 'center' }}>
                        <TouchableOpacity onPress={() => this.props.navigation.navigate('CutomeCmp')} >
                            <Text style={{ textAlign: 'center', color: '#000' }}>CustomeCmp</Text>
                        </TouchableOpacity>

                    </View>
                    <View style={{ height: 50, backgroundColor: '#fff', flexDirection: 'row', justifyContent: 'center', alignItems: 'center' }}>
                        <TouchableOpacity onPress={() => this.props.navigation.navigate('LogOut')} >
                            <Text style={{ textAlign: 'center', color: '#000' }}>LogOut</Text>
                        </TouchableOpacity>

                    </View>
                </View>
            </View>
        );
    }
}