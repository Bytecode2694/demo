import React, { Component } from 'react';
//import { Store } from 'redux';
//import welcomescreen from './src/Animationsrc'
//const AppNavigator =  createAppContainer(RootStack);
import { Button, View, Text, } from "react-native";
import Ionicons from "react-native-vector-icons/Ionicons"
import Feather from "react-native-vector-icons/Feather"
import { userProfile } from "../../actions/index"

import { connect } from "react-redux";

/**
 * 
 */
class Profile extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      type: 'USER_PROFILE',
      uname: '',
      pwd: '',
      name: ''
    }

  }

  componentDidMount() {
    var state = this.props.store;
    console.log(state);
  }

  render() {
    const { navigate } = this.props.navigation;
    return (
      <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>

        <Text>{this.props.firstname}</Text>
        <Feather name='anchor' onPress={() => {
          // action.pwd = 'u1908';
          this.props.dispatch(userProfile({ firstname: 'fortcollins' }));

        }
        } size={25} color='#ECB37C' />
      </View>


    );
  }
}

function mapStateToProps(state) {
  return {
    firstname: state.userProfile[0].firstname
  }
}

export default connect(mapStateToProps)(Profile)