import React from "react";
import { Button, View, Text, StyleSheet, TextInput } from "react-native";
import SplashScreen from "react-native-splash-screen";
import {connect} from "react-redux";
const action = {
  type: 'MODIFY_USERNAME',
  payload: 'new name',
};

 class Dashboard extends React.Component { 
  state = {
    username: '',
    password: '',
  }
    render() {
      const {navigate} = this.props.navigation;
      return (
        <View style={styles.container}>
          <View   style={{ backgroundColor: '#7CB5EC' ,height: 60, paddingTop: 0, }}>
            <Text   style={{color: '#fff'}}>Header</Text>
          </View>
          
        <Text style={styles.error}>{this.props.err}</Text>
        <TextInput
          placeholder="username"
          value={this.state.username}
          onChangeText={this.handleUsernameUpdate}
          autoCapitalize="none" 
        />
        <TextInput
          placeholder="password"
          value={this.state.password}
          onChangeText={this.handlePasswordUpdate}
          secureTextEntry
        />
        <Button title="Press to Log In" onPress={this._login} />
          <Button
          title="Go to Jane's Home"
          onPress={() => this.props.dispatch(action) }
        />
        </View>
      
      );
    }
  }

  
  export default connect(mapStateToProps)(Dashboard);

  const styles = StyleSheet.create({
    container: {
      justifyContent: 'center',
      flex: 1,
    },
    text: {
      textAlign: 'center',
    },
    error: {
      textAlign: 'center',
      color: 'red',
    },
  })