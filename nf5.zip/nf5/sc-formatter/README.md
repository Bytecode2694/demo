# sc-formatter
Module for serializing and unserializing SocketCluster messages
