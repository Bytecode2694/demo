# babel-helper-optimise-call-expression

## Usage

TODO
