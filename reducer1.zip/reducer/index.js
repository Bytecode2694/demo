import { combineReducers } from 'redux';
import loginUser from './loginUser';
import userProfile from './userProfile';
import movieList from './movieList';

export default combineReducers({
    loginUser,
    userProfile,
    movieList
})