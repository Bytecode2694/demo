import { fetchUsers } from "../src/APIRequest/requestMethods"
const movieinfo = {

    type: "MOVIE_LIST",
    response: "",
    count: "1"


}
function compareListObject(oldmovielist, newmovielist) {
    var flag = true;
    if (oldmovielist.length === 0) {
        return flag;
    }
    if (Object.keys(oldmovielist).length === Object.keys(newmovielist).length) {
        // for (key in oldmovielist) {
        //     if (oldmovielist[key] === newmovielist[key]) {
        //         continue;
        //     }
        //     else {
        //         flag = false;
        //         //  return flag;
        //     }
        // }
        flag = false;
    }
    else {
        flag = false;
        // return flag;
    }
    return flag;
}
export default movieList = (state = [movieinfo], action) => {
    switch (action.type) {
        case "MOVIE_LIST":
            try {
                // await fetchUsers(action.endpoint)
                // if (compareListObject(state[0].response, action.response)) {

                return [Object.assign(
                    ...state, action
                )

                ]
                // } else {
                //     return state
                // }

            } catch (error) {
                console.log(error.message);
            }
            break;
        default: return state
    }
}


