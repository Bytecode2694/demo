import React from "react";
import { Button, View, Text, Image, TextInput, SafeAreaView, Platform, StatusBar, ScrollView } from "react-native";
import Ionicons from "react-native-vector-icons/Ionicons"
import Feather from "react-native-vector-icons/Feather"
import { connect } from "react-redux";

export default class Tag extends React.Component { //require('../../../assets/images/1.png'
    render() {
        return (
            <View style={{
                minHeight: 20, minWidth: 40, marginRight: 5,
                padding: 5, backgroundColor: 'white',
                borderColor: '#dddddd', borderWidth: 1, borderRadius: 2
            }}>
                <Text style={{ fontWeight: '700', fontSize: 10 }}>{this.props.name}</Text>
            </View>
        )
    }
}