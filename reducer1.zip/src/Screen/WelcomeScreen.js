import React from "react";
import { Button, View, Text, } from "react-native";
import { connect } from "react-redux";
import { loadState, saveState } from "../../localstore/localStorageModule";
import SplashScreen from "react-native-splash-screen";
import { userLogin } from "../../actions/index"
class welcome extends React.Component {
  componentWillMount() {
    SplashScreen.hide();
  }
  render() {
    const { navigate } = this.props.navigation;
    return (
      <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
        <Text>{this.props.username}</Text>
        <Button
          title="Login"
          onPress={() => this.props.dispatch(userLogin({ username: 'suresh', password: 'suresh7884', isReady: false }))}
        />
        <Button
          title="Sign Up"
          onPress={() => this.props.navigation.navigate('InfiniteList')}
        />

      </View>

    );
    // this.props.navigation.navigate('Dashboard')  AnimatedHeader
  }
}


function mapStateToProps(state) {
  //const { username } = state

  return {
    username: state.loginUser[0].username
  }
}

export default connect(mapStateToProps)(welcome);