import {createStackNavigator, createAppContainer, createDrawerNavigator} from 'react-navigation';
import HomeScreen from "./HomeScreen";
import RootDrawer from "./DrawerMenu";
import DrawerLayout from "./DrawerLayout";
import DashboardScreen from "./Dashboard";
import React, {Component} from 'react';
import { Dimensions } from 'react-native';




const MainNavigator = createStackNavigator({
  Drawer: { screen: RootDrawer,
    navigationOptions: {
      header: null,
    } },
  Home: {screen: HomeScreen,
    navigationOptions: {
      header: null,
    }
  },
  Dashboard: { screen: DashboardScreen,
    navigationOptions: {
      header: null,
    }
   },

   DrawerStyle: {
    screen: DrawerLayout,
    
   }

 


},

{ 
  initialRouteName: 'Home', 
 
}
);

export default createAppContainer(MainNavigator);

