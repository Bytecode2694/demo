
# [6.1.0](https://github.com/start-react/native-starter-kit/releases/tag/v6.1.0)

### Enhancement Features

- **Upgrade:** Upgraded versions of React, [React Native](https://facebook.github.io/react-native/), [NativeBase](http://nativebase.io/), [CodePush](https://github.com/Microsoft/react-native-code-push).


### New Features

- **React Native Router Flux:** Added.
