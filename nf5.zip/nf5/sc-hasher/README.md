# sc-hasher
Default hashing function used by sc-broker-cluster to map channel names to brokers
