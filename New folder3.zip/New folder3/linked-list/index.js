'use strict';

module.exports = require('./_source/linked-list.js');
