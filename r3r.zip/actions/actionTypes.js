export const USER_LOGIN = "USER_LOGIN";
export const USER_PROFILE = "USER_PROFILE";
export const MOVIE_LIST = "MOVIE_LIST";