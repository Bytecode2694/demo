
// import React, { Component } from 'react';
// import PropTypes from 'prop-types'
// import { View, StyleSheet, Animated } from 'react-native';

// //import Expo, { Svg } from 'expo';
// import Svg, {
//     Circle,
//     ClipPath,
//     G,
//     LinearGradient,
//     Rect,
//     Defs,
//     Stop
// } from 'react-native-svg';

// const AnimatedSvg = Animated.createAnimatedComponent(Svg);
// const { interpolate } = require('d3-interpolate');

// export default class SvgAnimatedLinearGradient extends Component {
//     constructor(props) {
//         super(props);

//         this.state = {
//             offsetValues: [
//                 '-2', '-1.5', '-1'
//             ],
//             offsets: [
//                 '0.0001', '0.0002', '0.0003' // Avoid duplicate value cause error in Android
//             ],
//             frequence: props.duration / 2
//         }
//         this._isMounted = false;
//         this._animate = new Animated.Value(0)
//         this.loopAnimation = this
//             .loopAnimation
//             .bind(this)
//     }
//     offsetValueBound(x) {
//         if (x > 1) {
//             return '1'
//         }
//         if (x < 0) {
//             return '0'
//         }
//         return x
//     }
//     componentDidMount(props) {
//         this._isMounted = true
//         this.loopAnimation()
//     }
//     componentWillUnmount() {
//         this._isMounted = false
//     }
//     loopAnimation() {
//         if (!this._isMounted) return;
//         // setup interpolate
//         let interpolator = interpolate(this.state, {
//             offsetValues: ['1', '1.5', '2']
//         });

//         // start animation
//         let start = Date.now();
//         this._animation = () => {
//             const now = Date.now();
//             let t = (now - start) / this.props.duration;
//             if (t > 1) {
//                 t = 1
//             }

//             let newState = interpolator(t);
//             let offsetValues = [];
//             offsetValues[0] = this.offsetValueBound(newState.offsetValues[0]);
//             offsetValues[1] = this.offsetValueBound(newState.offsetValues[1]);
//             offsetValues[2] = this.offsetValueBound(newState.offsetValues[2]);

//             // Make sure at least two offsets is different
//             if (offsetValues[0] !== offsetValues[1] || offsetValues[0] !== offsetValues[2] || offsetValues[1] !== offsetValues[2]) {
//                 this._isMounted && this.setState({ offsets: offsetValues });
//             }
//             if (t < 1) {
//                 requestAnimationFrame(this._animation);
//             }
//         }
//         requestAnimationFrame(this._animation);

//         // Setup loop animation
//         Animated.sequence([
//             Animated.timing(this._animate, {
//                 toValue: 1,
//                 duration: this.state.frequence
//             }),
//             Animated.timing(this._animate, {
//                 toValue: 0,
//                 duration: this.state.frequence
//             })
//         ]).start((event) => {
//             if (event.finished) {
//                 this.loopAnimation()
//             }
//         })
//     }
//     render() {

//         return (
//             <AnimatedSvg {...this.props}>
//                 <Defs>
//                     <LinearGradient id="grad" x1={this.props.x1} y1={this.props.y1} x2={this.props.x2} y2={this.props.y2}>
//                         <Stop
//                             offset={this.state.offsets[0]}
//                             stopColor={this.props.primaryColor}
//                             stopOpacity="1" />
//                         <Stop
//                             offset={this.state.offsets[1]}
//                             stopColor={this.props.secondaryColor}
//                             stopOpacity="1" />
//                         <Stop
//                             offset={this.state.offsets[2]}
//                             stopColor={this.props.primaryColor}
//                             stopOpacity="1" />
//                     </LinearGradient>
//                     <ClipPath id="clip">
//                         <G>
//                             {this.props.children}
//                         </G>
//                     </ClipPath>
//                 </Defs>

//                 <Rect
//                     x="0"
//                     y="0"
//                     height={this.props.height}
//                     width={this.props.width}
//                     fill="url(#grad)"
//                     clipPath="url(#clip)" />
//             </AnimatedSvg>
//         );
//     }
// }
// SvgAnimatedLinearGradient.propTypes = {
//     primaryColor: PropTypes.string,
//     secondaryColor: PropTypes.string,
//     duration: PropTypes.number,
//     width: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
//     height: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
//     x1: PropTypes.string,
//     y1: PropTypes.string,
//     x2: PropTypes.string,
//     y2: PropTypes.string,
// }
// SvgAnimatedLinearGradient.defaultProps = {
//     primaryColor: '#eeeeee',
//     secondaryColor: '#dddddd',
//     duration: 2000,
//     width: 300,
//     height: 200,
//     x1: '0',
//     y1: '0',
//     x2: '100%',
//     y2: '0'

// }




import React, { Component } from "react";
import {
    View,
    Text,
    StyleSheet,
    SafeAreaView,
    TextInput,
    Platform,
    StatusBar,
    ScrollView,
    Image,
    Dimensions,
    Animated
} from "react-native";
import Icon from 'react-native-vector-icons/Ionicons'
import Category from '../../NewAppScreen/components/Category'
import Home from '../../NewAppScreen/components/HomeList'
import Tag from '../../NewAppScreen/components/Tag'
const { height, width } = Dimensions.get('window')
class SvgAnimatedLinearGradient extends Component {

    componentWillMount() {

        this.scrollY = new Animated.Value(0)

        this.startHeaderHeight = 80
        this.endHeaderHeight = 50
        if (Platform.OS == 'android') {
            this.startHeaderHeight = 100 + StatusBar.currentHeight
            this.endHeaderHeight = 70 + StatusBar.currentHeight
        }

        this.animatedHeaderHeight = this.scrollY.interpolate({
            inputRange: [0, 50],
            outputRange: [this.startHeaderHeight, this.endHeaderHeight],
            extrapolate: 'clamp'
        })

        this.animatedOpacity = this.animatedHeaderHeight.interpolate({
            inputRange: [this.endHeaderHeight, this.startHeaderHeight],
            outputRange: [0, 1],
            extrapolate: 'clamp'
        })
        this.animatedTagTop = this.animatedHeaderHeight.interpolate({
            inputRange: [this.endHeaderHeight, this.startHeaderHeight],
            outputRange: [-30, 10],
            extrapolate: 'clamp'
        })
        this.animatedMarginTop = this.animatedHeaderHeight.interpolate({
            inputRange: [this.endHeaderHeight, this.startHeaderHeight],
            outputRange: [50, 30],
            extrapolate: 'clamp'
        })


    }

    render() {
        return (
            <SafeAreaView style={{ flex: 1 }}>
                <View style={{ flex: 1 }}>
                    <Animated.View style={{ height: this.animatedHeaderHeight, backgroundColor: 'white', borderBottomWidth: 1, borderBottomColor: '#dddddd' }}>
                        <View style={{
                            flexDirection: 'row', padding: 10,
                            backgroundColor: 'white', marginHorizontal: 20,
                            shadowOffset: { width: 0, height: 0 },
                            shadowColor: 'black',
                            shadowOpacity: 0.2,
                            elevation: 1,
                            marginTop: Platform.OS == 'android' ? 30 : null
                        }}>
                            <Icon name="ios-search" size={20} style={{ marginRight: 10 }} />
                            <TextInput
                                underlineColorAndroid="transparent"
                                placeholder="Try New Delhi"
                                placeholderTextColor="grey"
                                style={{ flex: 1, fontWeight: '700', backgroundColor: 'white' }}
                            />
                        </View>
                        <Animated.View
                            style={{ flexDirection: 'row', marginHorizontal: 20, position: 'relative', top: this.animatedTagTop, opacity: this.animatedOpacity }}
                        >
                            <Tag name="Guests" />
                            <Tag name="Dates" />

                        </Animated.View>
                    </Animated.View>
                    <ScrollView
                        scrollEventThrottle={16}
                        onScroll={Animated.event(
                            [
                                { nativeEvent: { contentOffset: { y: this.scrollY } } }
                            ]
                        )}
                    >
                        <View style={{ flex: 1, backgroundColor: 'white', paddingTop: 20 }}>
                            <Text style={{ fontSize: 24, fontWeight: '700', paddingHorizontal: 20 }}>
                                What can we help you find, Varun?
                            </Text>

                            <View style={{ height: 130, marginTop: 20 }}>
                                <ScrollView
                                    horizontal={true}
                                    showsHorizontalScrollIndicator={false}
                                >
                                    <Category imageUri={require('../../../assets/images/b2.png')}
                                        name="Home"
                                    />
                                    <Category imageUri={require('../../../assets/images/b1.png')}
                                        name="Experiences"
                                    />
                                    <Category imageUri={require('../../../assets/images/4.png')}
                                        name="Resturant"
                                    />
                                </ScrollView>
                            </View>
                            <View style={{ marginTop: 40, paddingHorizontal: 20 }}>
                                <Text style={{ fontSize: 24, fontWeight: '700' }}>
                                    Introducing Airbnb Plus
                                </Text>
                                <Text style={{ fontWeight: '100', marginTop: 10 }}>
                                    A new selection of homes verified for quality & comfort

                                </Text>
                                <View style={{ width: width - 40, height: 200, marginTop: 20 }}>
                                    <Image
                                        style={{ flex: 1, height: null, width: null, resizeMode: 'cover', borderRadius: 5, borderWidth: 1, borderColor: '#dddddd' }}
                                        source={require('../../../assets/images/b2.png')}
                                    />

                                </View>
                            </View>
                        </View>
                        <View style={{ marginTop: 40 }}>
                            <Text style={{ fontSize: 24, fontWeight: '700', paddingHorizontal: 20 }}>
                                Homes around the world
                            </Text>
                            <View style={{ paddingHorizontal: 20, marginTop: 20, flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between' }}>
                                <Home width={width}
                                    name="The Cozy Place"
                                    type="PRIVATE ROOM - 2 BEDS"
                                    price={82}
                                    rating={4}
                                />
                                <Home width={width}
                                    name="The Cozy Place"
                                    type="PRIVATE ROOM - 2 BEDS"
                                    price={82}
                                    rating={4}
                                />
                                <Home width={width}
                                    name="The Cozy Place"
                                    type="PRIVATE ROOM - 2 BEDS"
                                    price={82}
                                    rating={4}
                                />


                            </View>
                        </View>
                    </ScrollView>

                </View>
            </SafeAreaView>
        );
    }
}
export default SvgAnimatedLinearGradient;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center'
    }
});