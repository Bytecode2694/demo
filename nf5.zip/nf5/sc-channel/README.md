# scchannel
Channels for SocketCluster
