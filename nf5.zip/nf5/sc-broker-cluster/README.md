sc-broker-cluster
=========

Realtime clustered broker engine for SocketCluster
