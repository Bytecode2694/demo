import React from 'react';
import { StyleSheet, TextInput, ActivityIndicator, FlatList, Text, View, Image } from 'react-native';


export default class InfiniteList extends React.Component {
    constructor() {
        super();
        this.state = {
            data: [],
            page: 1,
            isLoading: false
        }
        // this.page = 1;
    }
    componentDidMount() {
        this.setState({ isLoading: true }, this.getDataByPage)
        //;
    }
    getDataByPage = async () => {
        const url = 'https://jsonplaceholder.typicode.com/photos?_limit=10&_page=' + this.state.page;
        fetch(url).then((response) => response.json())
            .then((responsejson) => {
                this.setState({ data: [...this.state.data, ...responsejson], isLoading: false })
            })
    }

    renderRow = ({ item }) => {
        return (
            <View style={styles.item}>
                <Image style={styles.itemImage}
                    source={{ uri: item.url }} />
                <Text style={styles.itemText}>{item.id}</Text>
            </View>
        )
    }
    handleMore = async () => {
        //  this.page = this.page + 1;
        this.setState({ isLoading: true, page: this.state.page + 1 }, this.getDataByPage);


    }

    listFooter = () => {

        return (
            this.state.isLoading ? <View style={styles.loader}>
                <ActivityIndicator size='large' />
            </View> : null
        )


    }
    render() {
        return (
            <FlatList
                style={styles.container}
                data={this.state.data}
                renderItem={this.renderRow}
                keyExtractor={(item, index) => index.toString()}
                onEndReached={this.handleMore.bind(this)}
                onEndReachedThreshold={0.5}
                ListFooterComponent={this.listFooter}

            />
        );
    }
}


const styles = StyleSheet.create({
    container: {
        marginTop: 20,
        backgroundColor: '#f5fcff'
    },
    item: {
        backgroundColor: '#ccc',
        marginBottom: 10,
        borderBottomWidth: 1
    },
    itemText: {
        fontSize: 16,
        padding: 5
    },
    itemImage: {
        width: '100%',
        height: 200,
        resizeMode: 'cover'
    },
    loader: {
        marginTop: 10,
        alignItems: 'center'
    }


})