import { movieList } from '../../actions/index'

export const fetchUsers = async (endpoint, dispatch) => {
    // const response = await fetch('https://www.omdbapi.com/?s=batman&plot=full&apikey=thewdb')
    // const { results } = await response.json()
    // return results
    //'https://www.omdbapi.com/?s=batman&plot=full&apikey=thewdb'

    await fetch(endpoint)
        .then(response => response.json())
        .then(response => {
            console.log(response);
            dispatch(movieList(response.results));

            //return response.Search[0];
        })
        .catch(error => {
            console.log(error.message);
        });
}

// export const POSTAPICall = (endPoint, token, bodyData) => {
//     try {
//         // "DataBase": GlobalConstants.DBName
//         //  console.warn("\nGLOBALURL : " + GlobalConstants.GlobalUrl, "\nENDPOINT : " + endPoint, "\nTOKEN : " + GlobalConstants.ApiTokenValue, "\nDATABASE : " + GlobalConstants.DBName, "\nBODYDATA : " + bodyData);
//         return timeoutPromise(15000, fetch("http://52.172.47.229:6683/" + endPoint, {
//             method: "POST",
//             headers: {
//                 "Content-Type": "application/json",
//                 "Authorization": "Bearer " + "-kkpvjrm2pNtZ41N1wrfDc4Zkc4vrfkhHwlW8gTxxw_B19rVviga2a7VSXUJHtde7d22SSfLKSZfojQI8AWfe_y3KBZcNfguhI28tcxCTTG_KwPdVs0mper9Qx7w8juSTVAnSfk4ghtR2HvcSRH2yX7L--Oq-yN9kHVM6J-Zgt3gCaKnz4jy1JUaY6HGzjIwQRWk24M4JFhYbVuUpDx1NxJKdDyXv7UOxIelM4LrbJ5bkNGAN2xmrBQ19eTtczDH-c7B7BaHw1ZEL3AJqFNCJihcXfQmJ7_2Hl4wmgx6bZckLiaOJsJr5Q2AAWGncd7BMlQWJUceqSERWOxWeWtgPwFWt1PZZYeD9a5oro5gfpIyWjJVIHxo1EhAr5B9VRhg9tCfHs0NNJUYCzsBiQ0Ox7DetOlbaQ_WoJW2wIOq6rcv-g6Porg_H8gfn8Za5KA2kq8ayRHUhGxsE8UhIFm62tcfsMmSe_VQWOMVirmeFDw",
//                 //DataBase: GlobalConstants.DBName
//             },
//             body: bodyData
//         })).then(response =>
//             response.json()
//         )
//             .then(responseJson => {
//                 console.warn(responseJson);
//                 var responseObject = {
//                     StatusId: 200,
//                     StatusMessage: "Success",
//                     Response: responseJson
//                 };
//                 dispatch(movieList(response.results));
//             })
//             .catch(error => {
//                 var responseObject = {
//                     StatusId: 400,
//                     StatusMessage: "Network Issue .. Please Try Again ",
//                     Response: error
//                 };
//                 return responseObject;
//             });
//     } catch (e) {
//         console.log(e.message);
//     }
// };