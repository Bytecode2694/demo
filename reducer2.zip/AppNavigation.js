//import HomeScreen from "./src/HomeScreen";
//import RootStack from "./src/AppNavigator";
import DashboardScreen from "./src/Screen/Dashboard";
import welcomescreen from "./src/Screen/WelcomeScreen"
import React, { Component } from 'react';
//import welcomescreen from './src/Animationsrc'
//const AppNavigator =  createAppContainer(RootStack);
import { Button, View, Text, Dimensions, Easing, Animated } from "react-native";
import Ionicons from "react-native-vector-icons/Ionicons"
import Feather from "react-native-vector-icons/Feather"
import SplashScreen from "react-native-splash-screen";
import RegForm from "./src/Screen/form";
import Profile from "./src/Screen/Profile";
import Settings from "./src/Screen/Settings";
import Feed from "./src/Screen/Feed";
import DrawerItems from "./src/Screen/DrawerItems";
import MovieScreen from "./src/Screen/Movie";
import LogOutScreen from "./src/Screen/LogOut";
import TextInputClass from "./src/Screen/OTPScreen";
import CutomeCmp from "./src/Screen/CustomHeader";
import AnimatedHeader from "./src/Screen/AnimatedHeader/index";
import AnimatedHeaderScreen from "./src/Screen/AnimatedHeader/SvgAnimatedLinearGradient";
import SVG from "./src/Screen/SVGAnimation/index.js";
// CustomHeader from "./src/Screen/Header"
import { createStackNavigator, createAppContainer, createDrawerNavigator, createSwitchNavigator, createBottomTabNavigator } from 'react-navigation';
import { TextInput } from "react-native-gesture-handler";
import InfiniteList from "./src/Screen/InfiniteScroll";
const iconName = 'book-open';
/*  navigationOptions: {
    tabBarIcon: ({ focused, tintColor }) => {
        const iconName = `ios-checkmark${focused ? '' : '-circle'}`;
        return <Ionicons name={iconName} size={25} color={tintColor} />;
    },
}, */


const DashboardTabNavigator = createBottomTabNavigator({
  Feed: {
    screen: Feed,
    navigationOptions: {
      tabBarIcon: ({ focused, tintColor }) => {
        const iconName = 'book-open';
        return <Feather name={iconName} size={25} color={tintColor} active={focused} />;
      },
    }

  },
  Profile: {
    screen: Profile,
    navigationOptions: {
      tabBarIcon: ({ focused, tintColor }) => {
        const iconName = 'ios-star';
        return <Ionicons name={iconName} size={25} color={tintColor} />;
      },
    }
  },
  Settings: {
    screen: Settings,
    navigationOptions: {
      tabBarIcon: ({ focused, tintColor }) => {
        const iconName = 'ios-boat';
        return <Ionicons name={iconName} size={25} color={tintColor} />;
      },
    }
  }
},
  {
    navigationOptions: ({ navigation }) => {
      // alert("navigation"+navigation+"state"+navigation.state.index+"navigation routes"+navigation.state.routes[navigation.state.index].routeName);
      const { routName } = navigation.state.routes[navigation.state.index].routeName
      [navigation.state.index];
      // return(
      //   <View style={{flex: 1, flexDirection: 'row', justifyContent: 'center', alignItems: 'center'}}>
      //     <Text>{navigation.state.routes[navigation.state.index].routeName}</Text>
      //   </View>

      // );
      return {
        // headerRight: (
        //  <Button title={navigation.state.routes[navigation.state.index].routeName} onPress={()=> navigation.openDrawer()}>
        //  </Button>
        // ),

        // headerTitle: (
        //   <Button title={navigation.state.routes[navigation.state.index].routeName} onPress={()=> navigation.openDrawer()}>
        //   </Button>
        // ),
        // headerLeft: ( 
        //   <Button   title={navigation.state.routes[navigation.state.index].routeName} onPress={()=> navigation.openDrawer()}>
        //   </Button>
        // )
        headerTitle: (
          <View style={{ flex: 1, flexDirection: 'row' }}>
            <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', borderColor: '#efefef', borderWidth: 2 }}>
              <Button title={navigation.state.routes[navigation.state.index].routeName} onPress={() => navigation.openDrawer()}>
              </Button>
            </View>
          </View>
        )
      }
    },


  })

const DashboardStacknavigator = createStackNavigator({
  DashboardTabNavigator: {
    screen: DashboardTabNavigator
  },
  Form: {
    screen: RegForm,
    navigationOptions: ({ navigation }) => {
      return {
        headerRight: (
          <Button title='submit form' onPress={() => navigation.openDrawer()}>
          </Button>
        ),

        headerLeft: (
          <Button title='submit form' onPress={() => navigation.openDrawer()}>
          </Button>
        )
      }
    }
  },
  Movie: {
    screen: MovieScreen,

  },
  CutomeCmp: {
    screen: CutomeCmp
  },
  AnimatedHeader: {
    screen: AnimatedHeader
  },
  AnimatedHeaderScreen: {
    screen: AnimatedHeaderScreen
  },
  SVG: {
    screen: SVG
  },
  TextInput: {
    screen: TextInputClass
  },
  LogOut: {
    screen: LogOutScreen,

  },
  InfiniteList: {
    screen: InfiniteList
  }
  // CustomHeader: {
  //   screen: CustomHeader
  // },

},
  {
    headerMode: 'none',
    mode: 'card',
    defaultNavigationOptions: {
      gesturesEnabled: false,
    },
    transitionConfig: () => ({
      transitionSpec: {
        duration: 300,
        easing: Easing.out(Easing.poly(4)),
        timing: Animated.timing,
      },
      screenInterpolator: sceneProps => {
        const { layout, position, scene } = sceneProps;
        const { index } = scene;

        const height = layout.initHeight;
        const translateY = position.interpolate({
          inputRange: [index - 1, index, index + 1],
          outputRange: [height, 0, 0],
        });

        const opacity = position.interpolate({
          inputRange: [index - 1, index - 0.99, index],
          outputRange: [0, 1, 1],
        });

        return { opacity, transform: [{ translateY }] };
      },
    }),
  }
  // {
  //   defaultNavigationOptions: ({navigation }) => {
  //     return{
  //       headerLeft: (
  //         <Button title='Drawer' onPress={()=> navigation.openDrawer()}>
  //         </Button>
  //       )
  //     }
  //   }
  // }
)
/** navigationOptions: {
     drawerIcon: ({ focused, tintColor }) => {
         const iconName = `ios-checkmark${focused ? '' : '-circle'}`;
         return <Ionicons name={iconName} size={25} color={tintColor} />;
     },
   } */
const width = Dimensions.get("screen").width / 1.3;
const AppDrawerNavigator = createDrawerNavigator({
  Dashboard: {
    screen: DashboardStacknavigator,
    // navigationOptions: {
    //   drawerIcon: ({ focused, tintColor }) => {
    //       const iconName = `ios-checkmark${focused ? '' : '-circle'}`;
    //       return <Ionicons name={iconName} size={25} color={tintColor} />;
    //   },
    // }
  },
},
  {
    drawerBackgroundColor: 'transparent',
    hideStatusBar: false,
    drawerWidth: width,
    contentComponent: ({ navigation }) => (
      <DrawerItems navigation={navigation} />
    ),

  }
)

const AppSwitchNavigator = createSwitchNavigator({
  welcome: { screen: welcomescreen },
  Dashboard: { screen: AppDrawerNavigator }
})




const AppContainer = createAppContainer(
  AppSwitchNavigator
)

export default AppContainer;