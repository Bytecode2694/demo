# Installation
> `npm install --save @types/react-navigation`

# Summary
This package contains type definitions for react-navigation (https://github.com/react-community/react-navigation).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/react-navigation

Additional Details
 * Last updated: Wed, 25 Oct 2017 16:18:57 GMT
 * Dependencies: react, react-native
 * Global values: none

# Credits
These definitions were written by Huhuanming <https://github.com/huhuanming>, mhcgrq <https://github.com/mhcgrq>, fangpenlin <https://github.com/fangpenlin>, abrahambotros <https://github.com/abrahambotros>, petejkim <https://github.com/petejkim>, Kyle Roach <https://github.com/iRoachie>, phanalpha <https://github.com/phanalpha>, charlesfamu <https://github.com/charlesfamu>, Tim Wang <https://github.com/timwangdev>, Qibang Sun <https://github.com/bang88>.
