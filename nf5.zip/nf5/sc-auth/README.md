# sc-auth
Auth module for SocketCluster
