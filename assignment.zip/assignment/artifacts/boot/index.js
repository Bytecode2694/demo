import app from "./setup";
export default function () {
    return app;
}
//# sourceMappingURL=index.js.map