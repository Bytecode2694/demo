export default () => {
    const pickerTheme = {
        ".note": {
            color: "#8F8E95",
        },
        width: 90,
        marginRight: -4,
    };
    return pickerTheme;
};
//# sourceMappingURL=Picker.android.js.map