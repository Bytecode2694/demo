module.exports = require('./dist/base64url').default;
module.exports.default = module.exports;
