import React from "react";
import { Button, View, Text, Image, TextInput, SafeAreaView, Platform, StatusBar, ScrollView } from "react-native";
import Ionicons from "react-native-vector-icons/Ionicons"
import Feather from "react-native-vector-icons/Feather"
import { connect } from "react-redux";

export default class Category extends React.Component { //require('../../../assets/images/1.png'
    render() {
        return (
            <View style={{ height: 130, width: 130, marginLeft: 15, borderWidth: 0.5, borderColor: '#dddddd' }}>
                <View style={{ flex: 2 }}>
                    <Image source={this.props.imageUri}
                        style={{ flex: 1, width: null, height: null, resizeMode: 'cover' }} />
                </View>
                <View style={{ flex: 1, paddingLeft: 20, paddingTop: 10 }}>
                    <Text>{this.props.name}</Text>
                </View>
            </View>
        )
    }
}