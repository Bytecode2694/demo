# sc-errors
Error types for SocketCluster
