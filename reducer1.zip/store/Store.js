import { combineReducers, createStore, applyMiddleware } from 'redux';
import thunk from 'redux-thunk'
import RootReducer from "../reducer/index";
//import u from "../reducer/loginUser";
//import l from "../reducer/userProfile";
import { loadState, saveState } from "../localstore/localStorageModule";

//const RootReducer = combineReducers({ u, l });
const persistedState = loadState();
const Store = createStore(RootReducer, applyMiddleware(thunk));

// Store.subscribe(()=> {
//             saveState(Store.getState());
// });

export default Store;