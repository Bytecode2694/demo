import React from 'react';
import {
    AppRegistry,
    Image,
    PixelRatio,
    StyleSheet,
    Text,
    TouchableOpacity,
    View,
    Dimensions,
    SafeAreaView,
    ScrollView,
    TextInput,
    Platform
} from 'react-native';
import ImagePicker from 'react-native-image-picker';
//import Icon from 'react-native-vector-icons/Feather';
//import Ionicons from 'react-native-vector-icons/Ionicons'
import { Ionicons } from "../IconList/Ionicons";
import { Feat } from "../IconList/Feather"
const menuIcon = require("../../../assets/icon-menu.png");
const camIcon = require("../../../assets/cam.png");
const logo = require("../../../assets/logo12.jpg");//amazon_PNG7
const { height } = Dimensions.get('window');

class Header extends React.Component {

    constructor(props) {
        super(props);
    }

    render() {
        //flexDirection='row', justifyContent='row', alignItems='column' alignItems: 'center', justifyContent: 'center'  boderColor: '#efefef', borderWidth: 2,
        //boderColor: '#efefef', borderWidth: 2,
        try {
            if (this.props.issearchbar === 'searchbar') {
                return (
                    <View style={styles.Alignheader}>

                        <View style={{
                            flex: 1, backgroundColor: '#fff', borderRadius: 5, flexDirection: 'row', padding: 2,


                            opacity: 0.8,

                            elevation: 20,
                        }}>
                            <View style={{ flex: 0.1, paddingLeft: 4, alignItems: 'flex-start', justifyContent: 'center' }}>
                                <Ionicons name='ios-search' size={30} color='#777777' />
                            </View>
                            <View style={{ flex: 0.93, paddingLeft: 5, alignItems: 'flex-start', justifyContent: 'flex-end' }}>
                                <TextInput
                                    style={styles.textInput}
                                    underlineColorAndroid={'transparent'}
                                    editable
                                    returnKeyType='go'
                                    blurOnSubmit={false}
                                    placeholder={'Search'}
                                    placeholderTextColor={"#777777"}
                                    // autoFocus
                                    selectionColor={"#777777"}
                                />
                            </View>
                        </View>


                    </View>
                );
            } else if (this.props.issearchbar === 'basicheader') {
                return (
                    <View style={styles.Alignheader}>
                        <View style={{ flex: 0.2, borderColor: 'red', borderWidth: 2, alignItems: 'flex-start', justifyContent: 'center' }}>
                            <TouchableOpacity onPress={() => {
                                if (!(NavigateTo === "")) {
                                    this.props.navigation.navigate(this.props.NavigateTo);
                                }
                            }} >
                                <Image style={[styles.menuIcon, { color: this.props.Left.color }]} source={this.props.Left.leftcmp} />
                            </TouchableOpacity>
                        </View>
                        <View style={{ flex: 0.6, borderColor: 'red', borderWidth: 2, alignItems: 'center', justifyContent: 'center' }}>
                            <Text style={[styles.headerTitle, { color: this.props.Left.color }]}>{this.props.Body}</Text>
                        </View>

                        <View style={{ flex: 0.2, borderColor: 'red', borderWidth: 2, alignItems: 'flex-end', justifyContent: 'center' }}>
                            <Image style={styles.menuIcon} source={this.props.Right} />
                        </View>
                    </View>);
            } else {
                return (
                    <View style={{ flex: 1 }}>
                        <View style={{ flexDirection: 'row', height: 60, backgroundColor: '#b9b9b9' }}>
                            <View style={{ flex: 0.1, borderColor: 'red', borderWidth: 2, alignItems: 'flex-start', justifyContent: 'center' }}>
                                <TouchableOpacity onPress={() => {
                                    if (!(NavigateTo === "")) {
                                        this.props.navigation.navigate(this.props.NavigateTo);
                                    }
                                }} >
                                    <Image style={[styles.menuIcon, { color: this.props.Left.color }]} source={this.props.Left.leftcmp} />
                                </TouchableOpacity>
                            </View>
                            <View style={{ flex: 0.4, borderColor: 'red', borderWidth: 2, alignItems: 'flex-start', justifyContent: 'center' }} >
                                <TouchableOpacity>
                                    <Image style={[styles.logoIcon, { color: this.props.Left.color }]} source={logo} />

                                </TouchableOpacity>
                            </View>
                            <View style={{ flex: 0.4, borderColor: 'red', borderWidth: 2, alignItems: 'center', justifyContent: 'center' }} >

                            </View>
                            <View style={{ flex: 0.1, borderColor: 'red', borderWidth: 2, alignItems: 'flex-start', justifyContent: 'center' }} >
                                <Ionicons name="shopping-cart" size={30} color={'#fff'} />
                            </View>
                        </View>
                        <View style={{ flexDirection: 'row', height: 60, backgroundColor: '#efefef' }}>
                            <View style={styles.Alignheader}>
                                <View style={{
                                    flex: 1, backgroundColor: '#fff', borderRadius: 5, flexDirection: 'row', padding: 2,


                                    opacity: 0.8,

                                    elevation: 20,
                                }}>
                                    <View style={{ flex: 0.1, paddingLeft: 4, alignItems: 'flex-start', justifyContent: 'center' }}>
                                        <Ionicons name='ios-search' size={30} color='#777777' />
                                    </View>
                                    <View style={{ flex: 0.93, paddingLeft: 5, alignItems: 'flex-start', justifyContent: 'flex-end' }}>
                                        <TextInput
                                            style={styles.textInput}
                                            underlineColorAndroid={'transparent'}
                                            editable
                                            returnKeyType='go'
                                            blurOnSubmit={false}
                                            placeholder={'Search'}
                                            placeholderTextColor={"#777777"}
                                            // autoFocus
                                            selectionColor={"#777777"}
                                        />
                                    </View>
                                </View></View>
                        </View>
                        <View style={{ flexDirection: 'row', height: 60, backgroundColor: '#d4d4d4' }}>
                            <View style={{ flex: 0.25, borderColor: 'red', borderWidth: 2, alignItems: 'flex-start', justifyContent: 'center' }} >

                            </View>
                            <View style={{ flex: 0.25, borderColor: 'red', borderWidth: 2, alignItems: 'flex-start', justifyContent: 'center' }} >

                            </View>
                            <View style={{ flex: 0.25, borderColor: 'red', borderWidth: 2, alignItems: 'flex-start', justifyContent: 'center' }} >

                            </View>
                            <View style={{ flex: 0.25, borderColor: 'red', borderWidth: 2, alignItems: 'flex-start', justifyContent: 'center' }} >

                            </View>
                        </View>
                    </View >
                )
            }
        } catch (error) {
            console.log(error.message);
        }
    }

}

export default class App extends React.Component {
    state = {
        avatarSource: null,
        videoSource: null,
    };

    constructor(props) {
        super(props);

        this.selectPhotoTapped = this.selectPhotoTapped.bind(this);
        this.selectVideoTapped = this.selectVideoTapped.bind(this);
        this.state = {
            screenHeight: height,
        };

    }

    onContentSizeChange = (contentWidth, contentHeight) => {
        this.setState({ screenHeight: contentHeight });
    };

    selectPhotoTapped() {
        const options = {
            quality: 1.0,
            maxWidth: 500,
            maxHeight: 500,
            storageOptions: {
                skipBackup: true,
            },
        };

        ImagePicker.showImagePicker(options, (response) => {
            console.log('Response = ', response);

            if (response.didCancel) {
                console.log('User cancelled photo picker');
            } else if (response.error) {
                console.log('ImagePicker Error: ', response.error);
            } else if (response.customButton) {
                console.log('User tapped custom button: ', response.customButton);
            } else {
                let source = { uri: response.uri };

                // You can also display the image using data:
                // let source = { uri: 'data:image/jpeg;base64,' + response.data };

                this.setState({
                    avatarSource: source,
                });
            }
        });
    }

    selectVideoTapped() {
        const options = {
            title: 'Video Picker',
            takePhotoButtonTitle: 'Take Video...',
            mediaType: 'video',
            videoQuality: 'medium',
        };

        ImagePicker.showImagePicker(options, (response) => {
            console.log('Response = ', response);

            if (response.didCancel) {
                console.log('User cancelled video picker');
            } else if (response.error) {
                console.log('ImagePicker Error: ', response.error);
            } else if (response.customButton) {
                console.log('User tapped custom button: ', response.customButton);
            } else {
                this.setState({
                    videoSource: response.uri,
                });
            }
        });
    }


    render() {
        const scrollEnabled = this.state.screenHeight > height;
        //const navigation = this.props.navigation;
        return (
            <SafeAreaView style={styles.container}>
                <View style={styles.header}>
                    {/*this.renderHeader(menuIcon, "CommonDropdownList", "Store Attendance", camIcon)*/}
                    <Header
                        issearchbar={true}
                        Left={{ leftcmp: menuIcon, color: "red" }}
                        Right={camIcon}
                        Body={"Store Attendance"}
                        NavigateTo={"CommonDropdownList"}
                    />
                </View>
                {/* <View style={styles.body}>
                    {this.renderContent(scrollEnabled)}
                </View> */}
            </SafeAreaView>
        );
    }


    renderHeader(left, NavigateTo, body, right) {
        return (
            <View style={styles.Alignheader}>
                <View style={{ flex: 0.2, borderColor: 'red', borderWidth: 2, alignItems: 'flex-start', justifyContent: 'flex-start' }}>
                    <TouchableOpacity onPress={() => {
                        if (!(this.props.NavigateTo === "")) {
                            this.props.navigation.navigate(this.props.NavigateTo);
                        }
                    }} >
                        <Image style={styles.menuIcon} source={left} />
                    </TouchableOpacity>
                </View>
                <View style={{ flex: 0.6, borderColor: 'red', borderWidth: 2, alignItems: 'center', justifyContent: 'flex-start' }}>
                    <Text style={styles.headerTitle}>{body}</Text>
                </View>
                <View style={{ flex: 0.2, borderColor: 'red', borderWidth: 2, alignItems: 'center', justifyContent: 'flex-start' }}>
                    <Image style={styles.menuIcon} source={right} />
                </View>
            </View>

        );
    }
    renderContent(scrollEnabled) {
        return (
            <ScrollView style={styles.menuContainer}
                contentContainerStyle={styles.scrollview}
                scrollEnabled={scrollEnabled}
                onContentSizeChange={this.onContentSizeChange}  >
                <View style={styles.box} />
                <View style={styles.box} />
                <View style={styles.box} />
                <View style={styles.box} />
                <View style={styles.box} />
                <View style={styles.box} />
                <View style={styles.box} />
                <View style={styles.box} />
                <View style={styles.box} />
                <View style={styles.box} />
                <View style={styles.box} />
                <View style={styles.box} />
                <View style={styles.box} />
                <View style={styles.box} />
                <View style={styles.box} />
                <View style={styles.box} />
                <View style={styles.box} />
                <View style={styles.box} />
                <View style={styles.box} />
                <View style={styles.box} />
                <View style={styles.box} />
                <View style={styles.box} />
                <View style={styles.box} />
                <View style={styles.box} />
                <View style={styles.box} />
                <View style={styles.box} />
                <View style={styles.box} />
                <View>
                    <TouchableOpacity onPress={this.selectPhotoTapped.bind(this)}>
                        <View
                            style={[
                                styles.avatar,
                                styles.avatarContainer,
                                { marginBottom: 20 },
                            ]}
                        >
                            {this.state.avatarSource === null ? (
                                <Text>Select a Photo</Text>
                            ) : (
                                    <Image style={styles.avatar} source={this.state.avatarSource} />
                                )}
                        </View>
                    </TouchableOpacity>

                    <TouchableOpacity onPress={this.selectVideoTapped.bind(this)}>
                        <View style={[styles.avatar, styles.avatarContainer]}>
                            <Text>Select a Video</Text>
                        </View>
                    </TouchableOpacity>

                    {this.state.videoSource && (
                        <Text style={{ margin: 8, textAlign: 'center' }}>
                            {this.state.videoSource}
                        </Text>
                    )}
                </View>
                <View style={styles.box1} />

            </ScrollView>
        );
    }
}



const styles = StyleSheet.create({
    container: {
        ...StyleSheet.absoluteFillObject,
        flex: 1,
        // alignItems: 'stretch',
        backgroundColor: '#000'
    },
    header: {
        height: 180,
        paddingTop: 0,
        backgroundColor: '#111111',
        zIndex: 1001
    },
    Alignheader: {
        flex: 1,
        flexDirection: 'row',
        padding: 5,

    },
    searchbar: {
        backgroundColor: '#777777'
    },
    menuIcon: {
        width: 30,
        height: 30,

    },
    logoIcon: {
        width: 80,
        height: 30,

    },
    headerTitle: {
        color: 'white',
        fontSize: 20
    },
    body: {
        flexGrow: 1,
        zIndex: 1000
    },
    menuContainer: {
        flex: 1,
        paddingTop: 30,
        paddingHorizontal: 40,
        //snapToEnd: false,
        backgroundColor: "#223f6b",

    },
    scrollview: {
        flexGrow: 1,
    },
    textInput: {
        padding: 0,
        margin: 0,
        flex: 1,
        color: "#000",
        height: 20,
        fontSize: 16,

    },

    box: {
        width: 50,
        height: 50,
        backgroundColor: '#fff',
        borderColor: '#696969',
        borderWidth: 1,
        flexDirection: "row",
        justifyContent: "center",
        alignItems: "center",
        shadowColor: '#696969',
        borderRadius: 4,
        shadowOffset: {
            width: 0,
            height: 3,
        },
        shadowOpacity: 0.27,
        shadowRadius: 4.65,
        elevation: 6,
    },
    box1: {
        width: 50,
        height: 50,
        backgroundColor: 'transparent',
    }
    ,
    avatarContainer: {
        borderColor: '#9B9B9B',
        borderWidth: 1 / PixelRatio.get(),
        justifyContent: 'center',
        alignItems: 'center',
    },
    avatar: {
        borderRadius: 75,
        width: 150,
        height: 150,
    },

})

