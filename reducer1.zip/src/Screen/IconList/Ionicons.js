// const Feather = require("react-native-vector-icons/Feather");
// const Ionicons = require("react-native-vector-icons/Ionicons");

export default Ionicons = require("react-native-vector-icons/Ionicons");
