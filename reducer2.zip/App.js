import React, { Component } from 'react';
import { StatusBar } from 'react-native'
import { combineReducers, createStore } from 'redux';
import { Provider } from 'react-redux'
import AppContainer from './AppNavigation';
import store from "./store/Store";

//import Reducer from "./reducer/Reducer";
//const Store = createStore(Reducer);


export default class App extends Component {

  componentWillMount() {

    console.disableYellowBox = true;
  }

  render() {
    return (
      <Provider store={store} >
        <StatusBar barStyle="dark-content" hidden={false} backgroundColor="#fff" translucent={true} />
        <AppContainer />
      </Provider>

    );
  }
}
