
export default Feather = require("react-native-vector-icons/Feather");
