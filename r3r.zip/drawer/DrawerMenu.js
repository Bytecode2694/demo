
import PropTypes from 'prop-types';
import React, { Component } from 'react';
import styles from 'react-native/Libraries/NewAppScreen/components/Style';
import { NavigationActions } from 'react-navigation';
import { ScrollView, Text, View } from 'react-native';
import { createStackNavigator, createAppContainer, createDrawerNavigator } from 'react-navigation';
import LogInScreen from './Login';
import DashboardScreen from './Dashboard';
import DrawerLayout from "./DrawerLayout";

const RootDrawer = createDrawerNavigator(
  {
    Login: LogInScreen,
    Dashboard: DashboardScreen,
  },
  {
    intialRouteName: 'Login',
    drawerPosition: 'slide',
    //contentComponent: <DrawerLayout/>
  }
);
const DrawerContainer = createStackNavigator({
  Drawer: {
    screen: RootDrawer,
    navigationOptions: {
      header: null,
    }
  },


},
  {
    initialRouteName: 'Drawer',
  }
);


export default createAppContainer(DrawerContainer);