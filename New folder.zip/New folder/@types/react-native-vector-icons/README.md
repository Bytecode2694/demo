# Installation
> `npm install --save @types/react-native-vector-icons`

# Summary
This package contains type definitions for react-native-vector-icons (https://github.com/oblador/react-native-vector-icons).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/react-native-vector-icons

Additional Details
 * Last updated: Wed, 25 Oct 2017 16:18:57 GMT
 * Dependencies: react, react-native
 * Global values: none

# Credits
These definitions were written by Kyle Roach <https://github.com/iRoachie>, Tim Wang <https://github.com/timwangdev>.
