var SVGParser = require('./core');

SVGParser.prototype.markerElement = function(){
	// TODO
};
