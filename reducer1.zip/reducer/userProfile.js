const profileinfo = {
    type: "USER_PROFILE",
    firstname: '',
    lastname: '',
    department: '',
    city: '',
    salary: '',
    session: '',
}

export default profile = (state = [profileinfo], action) => {
    switch (action.type) {
        case "USER_PROFILE":
            {
                return [
                    Object.assign(
                        ...state,
                        {
                            type: "USER_PROFILE",
                            firstname: action.firstname,
                            lastname: '',
                            department: '',
                            city: '',
                            salary: '',
                            session: '',
                        })
                ]
            }

        default:
            return state
    }
}
