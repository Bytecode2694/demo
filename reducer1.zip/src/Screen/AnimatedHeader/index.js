import React, { Component } from 'react';
import { View, Text, Button } from 'react-native';
import { createStackNavigator, createAppContainer, createDrawerNavigator, createSwitchNavigator, createBottomTabNavigator } from 'react-navigation';
import Ionicons from "react-native-vector-icons/Ionicons"
import Feather from "react-native-vector-icons/Feather"
import MovieScreen from "../Movie";
import CutomeCmp from "../CustomHeader";
import AnimatedHeaderScreen from "./SvgAnimatedLinearGradient";

class Tab extends React.Component {
    render() {
        return (
            <View>
                <Text>Tab</Text>
            </View>
        )
    }
}
export default DashboardTabNavigator = createBottomTabNavigator({
    AnimatedHeaderScreen: {
        screen: AnimatedHeaderScreen,
        navigationOptions: {
            tabBarIcon: ({ focused, tintColor }) => {
                const iconName = 'ios-boat';
                return <Ionicons name={iconName} size={25} color={tintColor} />;
            },
        }
    },
    MovieScreen: {
        screen: MovieScreen,
        navigationOptions: {
            tabBarIcon: ({ focused, tintColor }) => {
                const iconName = 'book-open';
                return <Feather name={iconName} size={25} color={tintColor} active={focused} />;
            },
        }

    },
    CutomeCmp: {
        screen: CutomeCmp,
        navigationOptions: {
            tabBarIcon: ({ focused, tintColor }) => {
                const iconName = 'ios-star';
                return <Ionicons name={iconName} size={25} color={tintColor} />;
            },
        }
    },

},
    {
        navigationOptions: ({ navigation }) => {
            // alert("navigation"+navigation+"state"+navigation.state.index+"navigation routes"+navigation.state.routes[navigation.state.index].routeName);
            const { routName } = navigation.state.routes[navigation.state.index].routeName
            [navigation.state.index];
            // return(
            //   <View style={{flex: 1, flexDirection: 'row', justifyContent: 'center', alignItems: 'center'}}>
            //     <Text>{navigation.state.routes[navigation.state.index].routeName}</Text>
            //   </View>

            // );
            return {
                // headerRight: (
                //  <Button title={navigation.state.routes[navigation.state.index].routeName} onPress={()=> navigation.openDrawer()}>
                //  </Button>
                // ),

                // headerTitle: (
                //   <Button title={navigation.state.routes[navigation.state.index].routeName} onPress={()=> navigation.openDrawer()}>
                //   </Button>
                // ),
                // headerLeft: ( 
                //   <Button   title={navigation.state.routes[navigation.state.index].routeName} onPress={()=> navigation.openDrawer()}>
                //   </Button>
                // )
                headerTitle: (
                    <View style={{ flex: 1, flexDirection: 'row' }}>
                        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', borderColor: '#efefef', borderWidth: 2 }}>
                            <Button title={navigation.state.routes[navigation.state.index].routeName} onPress={() => navigation.openDrawer()}>
                            </Button>
                        </View>
                    </View>
                )
            }
        },


    })