// export default  modify_username = (state = {username: 'initial name'}, action) => {
//     switch (action.type) {
//         case 'MODIFY_USERNAME':
//             return {username: action.payload}
//         case 'USER_PROFILE': return { uname: action.uname, pwd: action.pwd, name: action.name }
//         default:
//             return state
//     }
// }   
const userinfo = {
    type: "USER_LOGIN",
    username: '',
    password: '',
    devicetype: '',
    domain: '',
    token: '',
    session: '',
}
const profileinfo = {
    type: "USER_PROFILE",
    firstname: '',
    lastname: '',
    department: '',
    city: '',
    salary: '',
    session: '',
}
export default user = (state = [userinfo], action) => {
    switch (action.type) {
        case "USER_LOGIN":
            try {
                return [
                    Object.assign(
                        ...state,
                        {
                            username: action.username,
                            password: action.password,
                            isReady: action.isReady,
                            devicetype: '',
                            domain: '',
                            token: '',
                            session: '',
                        })
                ]
            } catch (error) {

            }
            break;
        default:
            return state
    }

}
