foo(class Foo extends React.Component {});
foo(class extends React.Component {});
