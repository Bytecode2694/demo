import React from "react";
import { Button, View, Text, } from "react-native";
import SplashScreen from "react-native-splash-screen";
import { DrawerActions } from 'react-navigation';
import RootStack from './Dashboard'
export default class HomeScreen extends React.Component {
    componentWillMount(){
        SplashScreen.hide();
    }
    render() {
      const {navigate} = this.props.navigation;
      return (
        <View style={{flex:1 }}> 
          <View style={{ backgroundColor: '#7CB5EC' }}>
            <Text style={{color: '#fff'}}>Header</Text>
          </View>
                 <View>
            <Text onPress = {()=> navigate('Drawer')}>Open Drawer</Text>
          </View>
       <Button
          title="Go to Jane's Dashboard"
          onPress={() =>this.props.navigation.navigate('Dashboard')}
        />
        </View>
      
      );
    }
  }