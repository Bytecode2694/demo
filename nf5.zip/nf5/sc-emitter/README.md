# sc-emitter
Emitter implementation (based on component-emitter) with support for Node.js error domains
