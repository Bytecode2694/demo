import { StyleSheet } from "react-native";
const styles = StyleSheet.create({
    container: {
        backgroundColor: "#FBFAFA",
    },
});
export default styles;
//# sourceMappingURL=styles.js.map