exports.Surface = require('./canvas/surface');
exports.Path = require('./canvas/path');
exports.Shape = require('./canvas/shape');
exports.Group = require('./canvas/group');
exports.ClippingRectangle = require('./canvas/clippingrectangle');
exports.Text = require('./canvas/text');
