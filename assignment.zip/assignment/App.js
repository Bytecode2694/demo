import boot from "./artifacts/boot/index";

const app = boot();

export default app;
