import * as React from "react";
import BlankPage from "../../stories/screens/BlankPage";
export default class BlankPageContainer extends React.Component {
    render() {
        return React.createElement(BlankPage, { navigation: this.props.navigation });
    }
}
//# sourceMappingURL=index.js.map