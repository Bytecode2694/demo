# Installation
> `npm install --save @types/react-native`

# Summary
This package contains type definitions for react-native (https://github.com/facebook/react-native).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/react-native

Additional Details
 * Last updated: Thu, 31 Aug 2017 14:05:16 GMT
 * Dependencies: react
 * Global values: none

# Credits
These definitions were written by Eloy Durán <https://github.com/alloy>, Fedor Nezhivoi <https://github.com/gyzerok>, HuHuanming <https://github.com/huhuanming>, Kyle Roach <https://github.com/iRoachie>, Tim Wang <https://github.com/timwangdev>, Kamal Mahyuddin <https://github.com/kamal>.
