import React, {Component} from 'react';
//import welcomescreen from './src/Animationsrc'
//const AppNavigator =  createAppContainer(RootStack);
import { Button, View, Text, } from "react-native";
import Ionicons from "react-native-vector-icons/Ionicons"
import Feather from "react-native-vector-icons/Feather"

export default class Profile extends React.Component { 

    render(){
      const {navigate} = this.props.navigation;
      return (
        <View style={{flex:1, alignItems: 'center', justifyContent:'center'}}> 
          <Text>LogOut</Text>
        </View>
      );
    }
  }