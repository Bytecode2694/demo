export default () => {
    const pickerTheme = {};
    return pickerTheme;
};
//# sourceMappingURL=Picker.ios.js.map