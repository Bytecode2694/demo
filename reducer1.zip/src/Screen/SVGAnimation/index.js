import React, { Component } from "react";
import {
    View,
    Text,
    StyleSheet,
    SafeAreaView,
    TextInput,
    Platform,
    StatusBar,
    ScrollView,
    Image,
    Button,
    Dimensions,
    Animated,

} from "react-native";
import { connect } from "react-redux";
import SplashScreen from 'react-native-splash-screen';
import FastImage from 'react-native-fast-image'
import MusicApp from '../Modules/Music/index.js';
import { userLogin } from "../../../actions/index";

const { height, width } = Dimensions.get('window')

class SVG extends React.Component {
    constructor() {
        super()
        // this.state = {
        //     isReady: false,
        // }

    }

    async _loadAssetsAsync() {
        // return (<FastImage
        //     style={{ width: 200, height: 200 }}
        //     source={{
        //         uri: require('../../../assets/MusicImg/bg.jpg'),
        //         priority: FastImage.priority.normal,
        //     }}
        //     resizeMode={FastImage.resizeMode.contain}
        // />);

    }
    setApp() {

        this.props.dispatch(userLogin({ username: 'suresh', password: 'suresh7884', isReady: true }))
    }

    render() {
        if (!this.props.isReady) {
            // return (
            //     <View>
            //         {this._loadAssetsAsync()}
            //         {this.setApp()}
            //     </View>
            // )
            this.props.dispatch(userLogin({ username: 'suresh', password: 'suresh7884', isReady: true }))

        }

        return (
            <MusicApp />
        );
    }
}

function mapStateToProps(state) {
    //const { username } = state

    return {
        isReady: state.loginUser[0].isReady
    }
}


export default connect(mapStateToProps)(SVG);